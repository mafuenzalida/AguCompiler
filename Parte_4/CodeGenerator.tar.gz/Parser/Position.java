package Parser;

public class Position
{
    public Position (int line, int column) {
        this.line = line;
        this.column = column;
    }
    public int line;
    public int column;
}
