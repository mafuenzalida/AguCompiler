package Tree;

public abstract class ClassBody extends DeclTree
{

}
