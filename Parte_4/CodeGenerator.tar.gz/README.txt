Compile:
make
javac Main.java

Execute:
java Main File_Path

Output:
	Si hay errores:
		Se muestran errores
	Si no los hay
		Abstract Syntax Tree [Tipo de cada nodo]
	Output file

Output file:
	programa

