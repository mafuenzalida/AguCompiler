Compile:
make

Execute:
java Main File_Path

Output:
Abstract Syntax Tree
