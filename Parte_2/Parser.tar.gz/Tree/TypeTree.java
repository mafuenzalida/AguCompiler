package Tree;

public abstract class TypeTree extends ASTree
{

}
