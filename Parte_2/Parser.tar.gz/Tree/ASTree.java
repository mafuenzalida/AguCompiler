package Tree;

public abstract class ASTree
{
    public abstract void accept (TreeVisitor visitor);
}
