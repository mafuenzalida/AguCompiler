package Tree;

public abstract class DeclTree extends ASTree
{

}
