Compile:
make

Execute:
java Compiler File_Path

Output:
TYPE (value)? column row