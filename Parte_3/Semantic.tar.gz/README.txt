Compile:
make
javac Main.java

Execute:
java Main File_Path

Output:
	Si hay errores:
		Se muestran errores
	Si no los hay
		Abstract Syntax Tree [Tipo de cada nodo]
	Output file

Output file:
	-Variables y constantes por scope
	-Tipos globales
	-Clases: nombre_clase |Padre-> nombre_clase_padre
		Atributos

