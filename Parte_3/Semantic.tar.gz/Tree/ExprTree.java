package Tree;

public abstract class ExprTree extends ASTree
{
	
}
